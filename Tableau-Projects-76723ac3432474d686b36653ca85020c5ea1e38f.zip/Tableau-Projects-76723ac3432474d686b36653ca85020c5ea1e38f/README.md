# Tableau-Projects
Learnt Data Visualization and Data Analytics with Tableau by solving 3 Realistic Analytics Projects.
